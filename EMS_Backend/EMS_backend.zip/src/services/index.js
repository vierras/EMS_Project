import UserSevice from "./userServices";

const services = {
    UserSevice
  };
  
export default services;